## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  fig.width=5, fig.height=3,
  comment = "#>"
)
knitr::opts_knit$set(global.par = TRUE)
library(cophy)

## ---- include=FALSE------------------------------------------------------
  par(mar = rep(0.1,4))  # setting small margins

## ------------------------------------------------------------------------
  set.seed(1)  # setting random seed for reproducibility
  coph <- rcophylo(tmax = 5)

## ------------------------------------------------------------------------
  coph

## ------------------------------------------------------------------------
  plot(coph)

## ------------------------------------------------------------------------
  coph <- rcophylo(tmax = 5, lambda = 0.8, mu = 0)
  plot(coph)

## ------------------------------------------------------------------------
  coph <- rcophylo(tmax = 10, mu = 0.05, K = 50)
  plot(coph)

## ------------------------------------------------------------------------
  set.seed(1)
  htree <- rphylo_H(tmax = 5, lambda = 1, mu = 0.4)

## ------------------------------------------------------------------------
  plot(htree, root.edge = TRUE, show.tip.label = FALSE)

## ------------------------------------------------------------------------
  coph <- rcophylo(HTree = htree)
  plot(coph)

## ------------------------------------------------------------------------
  coph <- rcophylo(HTree = htree)
  plot(coph)

## ------------------------------------------------------------------------
  coph <- rcophylo(HTree = htree, beta = 0.1, nu = 0.5)
  plot(coph)

## ------------------------------------------------------------------------
  coph <- rcophylo(HTree = htree, beta = 0.1, nu = 0.1)
  plot(coph)

## ------------------------------------------------------------------------
  coph <- rcophylo(HTree = htree, beta = 1.0, nu = 1.5)
  plot(coph)

## ------------------------------------------------------------------------
  set.seed(1)
  coph <- rcophylo(HTree = htree, PStartT = 2)
  plot(coph)

## ------------------------------------------------------------------------
  set.seed(1)
  coph <- rcophylo(HTree = htree, beta = 3, nu = 1, gamma = 0.4)
  plot(coph)

## ------------------------------------------------------------------------
  coph <- rcophylo(HTree = htree, beta = 0.2, delta = 0.2)
  plot(coph)

## ------------------------------------------------------------------------
  set.seed(1)
  coph <- rcophylo(HTree = htree, beta = 1, nu = 0.5, sigma = 0.1)
  plot(coph)

## ------------------------------------------------------------------------
  plot(coph, parasiteCol = rgb(1, 0, 0, alpha = 0.5))

## ------------------------------------------------------------------------
  set.seed(1)
  coph <- rcophylo(HTree = htree, kappa = 0.5)
  plot(coph, parasiteCol = rgb(1, 0, 0, alpha = 0.5))

## ------------------------------------------------------------------------
  set.seed(1)  # setting random seed for reproducibility
  coph <- rcophylo(tmax = 5)
  plot(coph)
  get_infectionStatistics(coph)

## ------------------------------------------------------------------------
  coph <- rcophylo(tmax = 5, kappa = 0.5)
  plot(coph)
  get_infectionStatistics(coph)
  get_infectionFrequencies(coph)

## ------------------------------------------------------------------------
  set.seed(5)
  coph <- rcophylo(tmax = 5)
  plot(coph)
  get_PextinctionTime(coph)

## ------------------------------------------------------------------------
  set.seed(1)
  coph <- rcophylo(tmax = 5, beta = 0, nu = 0.05)
  plot(coph)

## ------------------------------------------------------------------------
  get_PHDistCorrelation(coph)

## ------------------------------------------------------------------------
  set.seed(1)
  coph <- rcophylo(tmax = 5)
  plot(coph)
  get_PHDistCorrelation(coph)

## ------------------------------------------------------------------------
  set.seed(2)
  coph <- rcophylo(tmax = 5, beta = 3, nu = 1, gamma = 0.4)
  plot(coph)
  get_PHDistCorrelation(coph)

## ------------------------------------------------------------------------
  start <- Sys.time()
  set.seed(1)
  htree <- rphylo_H(tmax = 10)
  coph <- rcophylo(HTree = htree)
  end <- Sys.time()
  plot(coph)
  print(paste0("Time needed for simulation: ", end-start,"s."))

## ------------------------------------------------------------------------
  start <- Sys.time()
  set.seed(1)
  htree <- rphylo_H(tmax = 10, exportFormat = "raw")
  coph <- rcophylo(HTree = htree)
  end <- Sys.time()
  plot(coph)
  print(paste0("Time needed for simulation: ", end-start,"s."))

